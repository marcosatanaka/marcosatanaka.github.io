--------------
-- APP INFO --
--------------

Release date: Tuesday, May 19, 2020

----------------------------
-- REQUIREMENTS AND LINKS --
----------------------------

Requires: iOS 13.4 or later

App Store link: not available yet

TestFlight link: https://testflight.apple.com/join/7nB33UMD

-------------
-- CONTACT --
-------------

For all press inquires and interviews, please contact:

Email: marcosatanaka@gmail.com
Twitter: @mactanaka
Website: https://marcosatanaka.com

------------------
-- REVIEW GUIDE --
------------------

MusicSmart was designed to work with the iOS Music app. In order to use the app, you need a device with a local media library synced with iTunes, or with an Apple Music media library.

To test the app, give access to your music library, or use the Action Extension right from the iOS Music app, and select "View details with MusicSmart".
