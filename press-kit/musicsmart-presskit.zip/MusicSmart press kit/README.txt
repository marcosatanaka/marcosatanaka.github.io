--------------
-- APP INFO --
--------------

Release date: Tuesday, May 19, 2020

----------------------------
-- REQUIREMENTS AND LINKS --
----------------------------

Requires: iOS 13.4 or later

App Store link: https://apps.apple.com/us/app/musicsmart/id1512195368

-------------
-- CONTACT --
-------------

For all press inquires and interviews, please contact:

Email: marcosatanaka@gmail.com
Twitter: @mactanaka
Website: https://marcosatanaka.com

------------------
-- REVIEW GUIDE --
------------------

MusicSmart was designed to work with local music libraries, Apple Music, and Spotify. In order to use the app, you need a device with a local media library synced with iTunes, with an Apple Music media library, or a Spotify account.

To test the app with a local media library or Apple Music, give access to your music library, or use the Action Extension right from the iOS Music app, and select "View details with MusicSmart".

To test the app with Spotify, connect your account and use MusicSmart to explore your Spotify music library.