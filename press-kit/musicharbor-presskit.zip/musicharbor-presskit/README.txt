--------------
-- APP INFO --
--------------

Release date: November 21, 2018

----------------------------
-- REQUIREMENTS AND LINKS --
----------------------------

Requires: iOS 11.0 or greater

App Store link: https://itunes.apple.com/us/app/musicharbor/id1440405750

-------------
-- CONTACT --
-------------

For all press inquires and interviews, please contact:

Email: marcosatanaka@gmail.com
Twitter: @mactanaka
Site: https://marcosatanaka.com