--------------
-- APP INFO --
--------------

Release date: November 21, 2018

----------------------------
-- REQUIREMENTS AND LINKS --
----------------------------

Requires: iOS 13.0 or later

App Store link: https://apps.apple.com/us/app/musicharbor/id1440405750

-------------
-- CONTACT --
-------------

For all press inquires and interviews, please contact:

Email: marcosatanaka@gmail.com
Twitter: @mactanaka
Website: https://marcosatanaka.com